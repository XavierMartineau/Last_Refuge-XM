# Personnage 3D — LAST REFUGE · XM

Escape room de survie dans un pénitencier militaire post-apocalyptique (thème prison / bunker / zombie).
Ce dossier contient tout le système du **détenu 3D personnalisable** : le joueur compose son personnage
pièce par pièce (corps, tête, cheveux, tenue, accessoires, arme…), puis le joue en 3e / 1re personne.

## Objectif de la refonte
Refaire ces modèles en **vrais modèles 3D de meilleure qualité** (plus détaillés, mieux proportionnés,
cohérents entre eux), en gardant :
- le même découpage en catégories et le même nombre de variantes par catégorie (liste ci-dessous) ;
- la compatibilité entre pièces : toutes les pièces s’assemblent sur le même corps ;
- le style : réaliste-stylisé, sombre, militaire / survie, lisible de loin en jeu (vue 3e personne) ;
- des fichiers `.glb` légers (jeu web three.js, une scène avec beaucoup d’objets).

## Contenu
- `docs/assets/creation-personnage/` — la bibliothèque :
  - un dossier par catégorie, avec un fichier `.js` qui **génère** chaque pièce en code (three.js)
    et un sous-dossier `modeles/` avec l’export `.glb` de chaque variante (même nom, numérotée) ;
  - `assemblage/personnage.js` : assemble toutes les pièces sur le corps (positions, attaches,
    animations de marche, accroupi, visée…) ; `assemblage/modeles/detenu-par-defaut.glb` : détenu complet par défaut ;
  - `donnees/` : liste des choix, palettes de couleurs (`palettes.json`), validation des sélections ;
  - `materiaux/`, `outils/` : matériaux et fonctions de construction partagés ;
  - `personnage_armes.js` : point d’entrée unique utilisé par le jeu et le créateur.
- `docs/html|css|js/createur-personnage/` — la page du créateur de personnage (interface + aperçu 3D).
- `docs/html/dev/export-glb.html` — l’outil qui exporte chaque pièce générée en `.glb`.

Les couleurs sont appliquées par le code (palettes), donc les modèles doivent rester recolorables
(matériaux séparés par zone : peau, tissu principal, tissu secondaire, métal, cuir…).

## Catégories (nombre de modèles .glb)
- `armes` : 12
- `assemblage` : 1
- `barbes` : 9
- `bottes` : 9
- `bras` : 8
- `cheveux` : 34
- `corps` : 0
- `couvre-chefs` : 17
- `details-visage` : 16
- `donnees` : 0
- `equipement` : 8
- `especes` : 14
- `gants` : 7
- `lunettes` : 11
- `materiaux` : 0
- `outils` : 0
- `pantalons` : 9
- `sacs-a-dos` : 7
- `tenues` : 10
- `tete` : 0
- `visage` : 46
